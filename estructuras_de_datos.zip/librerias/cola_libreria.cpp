#include <iostream>
#include <queue>
using namespace std;

int main() {
    queue<int> cola;
    int opcion, valor;

    do {
        cout << "\n--- MENU COLA (STL std::queue) ---" << endl;
        cout << "1. Encolar (push)" << endl;
        cout << "2. Desencolar (pop)" << endl;
        cout << "3. Ver Frente (front)" << endl;
        cout << "4. Salir" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                cout << "Ingrese valor: ";
                cin >> valor;
                cola.push(valor);
                cout << "Elemento " << valor << " encolado." << endl;
                break;
            case 2:
                if (cola.empty()) {
                    cout << "Cola vacia." << endl;
                } else {
                    cout << "Elemento " << cola.front() << " desencolado." << endl;
                    cola.pop();
                }
                break;
            case 3:
                if (cola.empty()) {
                    cout << "Cola vacia." << endl;
                } else {
                    cout << "El frente de la cola es: " << cola.front() << endl;
                }
                break;
            case 4:
                cout << "Saliendo..." << endl;
                break;
            default:
                cout << "Opcion invalida." << endl;
        }
    } while (opcion != 4);

    return 0;
}
