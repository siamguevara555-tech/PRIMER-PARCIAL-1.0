// Ejercicio 8: Pila Dinámica con Librería Estándar (std::stack)
#include <iostream>
#include <stack>
using namespace std;

int main() {
    stack<int> pila; 
    int opcion, valor;

    do {
        cout << "\nPILA: ¿Qué desea hacer?" << endl;
        cout << "1. Apilar" << endl;
        cout << "2. Desapilar" << endl;
        cout << "3. Ver el elemento del tope" << endl;
        cout << "4. Mostrar toda la pila" << endl;
        cout << "5. Finalizar" << endl;
        cout << "Elige una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                cout << "Ingresa un numero para apilar: ";
                cin >> valor;
                pila.push(valor);
                cout << valor << " apilado." << endl;
                break;

            case 2:
                if (pila.empty()) { 
                    cout << "La pila esta vacia, no se puede desapilar." << endl;
                } else {
                    cout << "Se desapilo: " << pila.top() << endl;
                    pila.pop(); 
                }
                break;

            case 3:
                if (pila.empty()) {
                    cout << "La pila esta vacia." << endl;
                } else {
                    cout << "Elemento en el tope: " << pila.top() << endl;
                }
                break;

            case 4:
                if (pila.empty()) {
                    cout << "La pila esta vacia." << endl;
                } else {
                    stack<int> copia = pila;
                    cout << "Pila desde el tope hasta la base: ";
                    while (!copia.empty()) {
                        cout << copia.top() << " ";
                        copia.pop();
                    }
                    cout << endl;
                }
                break;

            case 5:
                cout << "Fin de programa." << endl;
                break;

            default:
                cout << "Opcion no valida." << endl;
        }

    } while (opcion != 5);

    return 0;
}