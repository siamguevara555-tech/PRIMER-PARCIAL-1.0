// Ejercicio 10: Lista Dinámica con Librería Estándar (std::list)

#include <iostream>
#include <list>
using namespace std;

int main() {
    list<int> lista;
    int opcion, valor;

    do {
        cout << "\nLISTA:" << endl;
        cout << "1. Insertar al inicio" << endl;
        cout << "2. Insertar al final" << endl;
        cout << "3. Eliminar el primer elemento" << endl;
        cout << "4. Eliminar el ultimo elemento" << endl;
        cout << "5. Mostrar toda la lista" << endl;
        cout << "6. Fin" << endl;
        cout << "Elige una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                cout << "Ingresa un numero: ";
                cin >> valor;
                lista.push_front(valor); 
                cout << valor << " se inserto al inicio." << endl;
                break;

            case 2:
                cout << "Ingresa un numero: ";
                cin >> valor;
                lista.push_back(valor); 
                cout << valor << " se inserto al final." << endl;
                break;

            case 3:
                if (lista.empty()) {
                    cout << "La lista esta vacia." << endl;
                } else {
                    cout << "Se elimino: " << lista.front() << endl;
                    lista.pop_front();
                }
                break;
                
            case 4:
                if (lista.empty()) {
                    cout << "La lista esta vacia." << endl;
                } else {
                    cout << "Se elimino: " << lista.back() << endl;
                    lista.pop_back();
                }
                break;

            case 5:
                if (lista.empty()) {
                    cout << "La lista esta vacia." << endl;
                } else {
                    cout << "Lista: ";
                    for (int v : lista) {
                        cout << v << " ";
                    }
                    cout << endl;
                }
                break;

            case 6:
                cout << "Fin de programa" << endl;
                break;

            default:
                cout << "Opcion no valida." << endl;
        }

    } while (opcion != 6);

    return 0;
}