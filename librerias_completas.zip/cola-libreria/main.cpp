//Ejercicio 9: Cola Dinámica con Librería Estándar (std::queue)

#include <iostream>
#include <queue>
using namespace std;

int main() {
    queue<int> cola;
    int opcion, valor;

    do {
        cout << "\nCOLA: ¿Que desea hacer?" << endl;
        cout << "1. Encolar" << endl;
        cout << "2. Desencolar" << endl;
        cout << "3. Ver el primero de la cola" << endl;
        cout << "4. Mostrar toda la cola" << endl;
        cout << "5. Finalizar" << endl;
        cout << "Elige una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                cout << "Ingresa un numero para encolar: ";
                cin >> valor;
                cola.push(valor); 
                cout << valor << " fue encolado." << endl;
                break;

            case 2:
                if (cola.empty()) {
                    cout << "La cola esta vacia, no se puede desencolar." << endl;
                } else {
                    cout << "Se desencolo: " << cola.front() << endl;
                    cola.pop(); 
                }
                break;

            case 3:
                if (cola.empty()) {
                    cout << "La cola esta vacia." << endl;
                } else {
                    cout << "El primero en la cola: " << cola.front() << endl;
                }
                break;

            case 4:
                if (cola.empty()) {
                    cout << "La cola esta vacia." << endl;
                } else {
                    queue<int> copia = cola;
                    cout << "Cola de inicio a fin: ";
                    while (!copia.empty()) {
                        cout << copia.front() << " ";
                        copia.pop();
                    }
                    cout << endl;
                }
                break;

            case 5:
                cout << "Finalizando" << endl;
                break;

            default:
                cout << "Opcion no valida." << endl;
        }

    } while (opcion != 5); 

    return 0;
}