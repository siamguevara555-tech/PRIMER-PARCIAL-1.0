#include <iostream>
using namespace std;

struct Nodo {
    int dato;
    Nodo* siguiente;
};

class ColaPunteros {
private:
    Nodo* frente;
    Nodo* fin;

public:
    ColaPunteros() { frente = fin = nullptr; }

    ~ColaPunteros() {
        while (frente != nullptr) {
            desencolar();
        }
    }

    void encolar(int valor) {
        Nodo* nuevo = new Nodo();
        nuevo->dato = valor;
        nuevo->siguiente = nullptr;
        if (fin == nullptr) {
            frente = fin = nuevo;
        } else {
            fin->siguiente = nuevo;
            fin = nuevo;
        }
        cout << "Elemento " << valor << " encolado dinamicamente." << endl;
    }

    void desencolar() {
        if (frente == nullptr) {
            cout << "Cola vacia." << endl;
        } else {
            Nodo* aux = frente;
            cout << "Elemento " << aux->dato << " desencolado." << endl;
            frente = frente->siguiente;
            if (frente == nullptr) fin = nullptr;
            delete aux;
        }
    }

    void mostrar() {
        if (frente == nullptr) {
            cout << "Cola vacia." << endl;
        } else {
            Nodo* aux = frente;
            cout << "Cola (memoria dinamica): ";
            while (aux != nullptr) {
                cout << aux->dato << " -> ";
                aux = aux->siguiente;
            }
            cout << "NULL" << endl;
        }
    }
};

int main() {
    ColaPunteros cola;
    int opcion, valor;

    do {
        cout << "
--- MENU COLA (PUNTEROS DINÁMICOS) ---" << endl;
        cout << "1. Encolar (Push)" << endl;
        cout << "2. Desencolar (Pop)" << endl;
        cout << "3. Mostrar" << endl;
        cout << "4. Salir" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                cout << "Ingrese valor: ";
                cin >> valor;
                cola.encolar(valor);
                break;
            case 2:
                cola.desencolar();
                break;
            case 3:
                cola.mostrar();
                break;
            case 4:
                cout << "Saliendo..." << endl;
                break;
            default:
                cout << "Opcion invalida." << endl;
        }
    } while (opcion != 4);

    return 0;
}
