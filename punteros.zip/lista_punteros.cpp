#include <iostream>
using namespace std;

struct Nodo {
    int dato;
    Nodo* siguiente;
};

class ListaPunteros {
private:
    Nodo* cabeza;

public:
    ListaPunteros() { cabeza = nullptr; }

    ~ListaPunteros() {
        Nodo* aux = cabeza;
        while (aux != nullptr) {
            Nodo* temp = aux;
            aux = aux->siguiente;
            delete temp;
        }
    }

    void insertar(int valor) {
        Nodo* nuevo = new Nodo();
        nuevo->dato = valor;
        nuevo->siguiente = cabeza;
        cabeza = nuevo;
        cout << "Elemento " << valor << " insertado al inicio." << endl;
    }

    void eliminar(int valor) {
        if (cabeza == nullptr) {
            cout << "Lista vacia." << endl;
            return;
        }

        if (cabeza->dato == valor) {
            Nodo* temp = cabeza;
            cabeza = cabeza->siguiente;
            delete temp;
            cout << "Elemento " << valor << " eliminado." << endl;
            return;
        }

        Nodo* aux = cabeza;
        while (aux->siguiente != nullptr && aux->siguiente->dato != valor) {
            aux = aux->siguiente;
        }

        if (aux->siguiente == nullptr) {
            cout << "Elemento " << valor << " no encontrado." << endl;
        } else {
            Nodo* temp = aux->siguiente;
            aux->siguiente = temp->siguiente;
            delete temp;
            cout << "Elemento " << valor << " eliminado." << endl;
        }
    }

    void mostrar() {
        if (cabeza == nullptr) {
            cout << "Lista vacia." << endl;
        } else {
            Nodo* aux = cabeza;
            cout << "Lista enlazada: ";
            while (aux != nullptr) {
                cout << aux->dato << " -> ";
                aux = aux->siguiente;
            }
            cout << "NULL" << endl;
        }
    }
};

int main() {
    ListaPunteros lista;
    int opcion, valor;

    do {
        cout << "
--- MENU LISTA ENLAZADA (PUNTEROS) ---" << endl;
        cout << "1. Insertar al inicio" << endl;
        cout << "2. Eliminar por valor" << endl;
        cout << "3. Mostrar" << endl;
        cout << "4. Salir" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                cout << "Ingrese valor: ";
                cin >> valor;
                lista.insertar(valor);
                break;
            case 2:
                cout << "Ingrese valor a eliminar: ";
                cin >> valor;
                lista.eliminar(valor);
                break;
            case 3:
                lista.mostrar();
                break;
            case 4:
                cout << "Saliendo..." << endl;
                break;
            default:
                cout << "Opcion invalida." << endl;
        }
    } while (opcion != 4);

    return 0;
}
