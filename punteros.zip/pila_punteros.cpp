#include <iostream>
using namespace std;

struct Nodo {
    int dato;
    Nodo* siguiente;
};

class PilaPunteros {
private:
    Nodo* tope;

public:
    PilaPunteros() { tope = nullptr; }

    ~PilaPunteros() {
        while (tope != nullptr) {
            desapilar();
        }
    }

    void apilar(int valor) {
        Nodo* nuevo = new Nodo();
        nuevo->dato = valor;
        nuevo->siguiente = tope;
        tope = nuevo;
        cout << "Elemento " << valor << " apilado dinamicamente." << endl;
    }

    void desapilar() {
        if (tope == nullptr) {
            cout << "Pila vacia." << endl;
        } else {
            Nodo* aux = tope;
            cout << "Elemento " << aux->dato << " desapilado." << endl;
            tope = tope->siguiente;
            delete aux;
        }
    }

    void mostrar() {
        if (tope == nullptr) {
            cout << "Pila vacia." << endl;
        } else {
            Nodo* aux = tope;
            cout << "Pila (memoria dinamica): ";
            while (aux != nullptr) {
                cout << aux->dato << " -> ";
                aux = aux->siguiente;
            }
            cout << "NULL" << endl;
        }
    }
};

int main() {
    PilaPunteros pila;
    int opcion, valor;

    do {
        cout << "
--- MENU PILA (PUNTEROS DINÁMICOS) ---" << endl;
        cout << "1. Apilar (Push)" << endl;
        cout << "2. Desapilar (Pop)" << endl;
        cout << "3. Mostrar" << endl;
        cout << "4. Salir" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                cout << "Ingrese valor: ";
                cin >> valor;
                pila.apilar(valor);
                break;
            case 2:
                pila.desapilar();
                break;
            case 3:
                pila.mostrar();
                break;
            case 4:
                cout << "Saliendo..." << endl;
                break;
            default:
                cout << "Opcion invalida." << endl;
        }
    } while (opcion != 4);

    return 0;
}
