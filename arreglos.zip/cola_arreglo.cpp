#include <iostream>
using namespace std;

#define MAX 5

class ColaArreglo {
private:
    int datos[MAX];
    int frente, fin;

public:
    ColaArreglo() {
        frente = -1;
        fin = -1;
    }

    bool estaLlena() { return fin == MAX - 1; }
    bool estaVacia() { return frente == -1 || frente > fin; }

    void encolar(int valor) {
        if (estaLlena()) {
            cout << "Cola llena." << endl;
        } else {
            if (frente == -1) frente = 0;
            datos[++fin] = valor;
            cout << "Elemento " << valor << " encolado." << endl;
        }
    }

    void desencolar() {
        if (estaVacia()) {
            cout << "Cola vacia." << endl;
        } else {
            cout << "Elemento " << datos[frente++] << " desencolado." << endl;
            if (frente > fin) { frente = fin = -1; } // Reiniciar cola
        }
    }

    void mostrar() {
        if (estaVacia()) {
            cout << "Cola vacia." << endl;
        } else {
            cout << "Contenido de la cola: ";
            for (int i = frente; i <= fin; i++) {
                cout << datos[i] << " ";
            }
            cout << endl;
        }
    }
};

int main() {
    ColaArreglo cola;
    int opcion, valor;

    do {
        cout << "
--- MENU COLA (ARREGLO ESTÁTICO) ---" << endl;
        cout << "1. Encolar (Push)" << endl;
        cout << "2. Desencolar (Pop)" << endl;
        cout << "3. Mostrar" << endl;
        cout << "4. Salir" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                cout << "Ingrese valor: ";
                cin >> valor;
                cola.encolar(valor);
                break;
            case 2:
                cola.desencolar();
                break;
            case 3:
                cola.mostrar();
                break;
            case 4:
                cout << "Saliendo..." << endl;
                break;
            default:
                cout << "Opcion invalida." << endl;
        }
    } while (opcion != 4);

    return 0;
}
