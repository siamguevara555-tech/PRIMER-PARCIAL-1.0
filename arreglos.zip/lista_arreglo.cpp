#include <iostream>
using namespace std;

#define MAX 5

class ListaArreglo {
private:
    int datos[MAX];
    int tam;

public:
    ListaArreglo() { tam = 0; }

    bool estaLlena() { return tam == MAX; }
    bool estaVacia() { return tam == 0; }

    void insertar(int valor) {
        if (estaLlena()) {
            cout << "Lista llena." << endl;
        } else {
            datos[tam++] = valor;
            cout << "Elemento " << valor << " insertado." << endl;
        }
    }

    void eliminar(int pos) {
        if (estaVacia() || pos < 0 || pos >= tam) {
            cout << "Posicion invalida o lista vacia." << endl;
        } else {
            cout << "Elemento " << datos[pos] << " eliminado." << endl;
            for (int i = pos; i < tam - 1; i++) {
                datos[i] = datos[i + 1];
            }
            tam--;
        }
    }

    void mostrar() {
        if (estaVacia()) {
            cout << "Lista vacia." << endl;
        } else {
            cout << "Contenido de la lista: ";
            for (int i = 0; i < tam; i++) {
                cout << "[" << i << "]: " << datos[i] << "  ";
            }
            cout << endl;
        }
    }
};

int main() {
    ListaArreglo lista;
    int opcion, valor, pos;

    do {
        cout << "
--- MENU LISTA (ARREGLO ESTÁTICO) ---" << endl;
        cout << "1. Insertar" << endl;
        cout << "2. Eliminar por indice" << endl;
        cout << "3. Mostrar" << endl;
        cout << "4. Salir" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                cout << "Ingrese valor: ";
                cin >> valor;
                lista.insertar(valor);
                break;
            case 2:
                cout << "Ingrese indice a eliminar: ";
                cin >> pos;
                lista.eliminar(pos);
                break;
            case 3:
                lista.mostrar();
                break;
            case 4:
                cout << "Saliendo..." << endl;
                break;
            default:
                cout << "Opcion invalida." << endl;
        }
    } while (opcion != 4);

    return 0;
}
