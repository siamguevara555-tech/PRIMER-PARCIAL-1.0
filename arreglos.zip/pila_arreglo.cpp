#include <iostream>
using namespace std;

#define MAX 5

class PilaArreglo {
private:
    int datos[MAX];
    int tope;

public:
    PilaArreglo() { tope = -1; }

    bool estaLlena() { return tope == MAX - 1; }
    bool estaVacia() { return tope == -1; }

    void apilar(int valor) {
        if (estaLlena()) {
            cout << "Pila llena (Overflow)." << endl;
        } else {
            datos[++tope] = valor;
            cout << "Elemento " << valor << " apilado correctamente." << endl;
        }
    }

    void desapilar() {
        if (estaVacia()) {
            cout << "Pila vacia (Underflow)." << endl;
        } else {
            cout << "Elemento " << datos[tope--] << " desapilado." << endl;
        }
    }

    void mostrar() {
        if (estaVacia()) {
            cout << "Pila vacia." << endl;
        } else {
            cout << "Contenido de la pila: ";
            for (int i = tope; i >= 0; i--) {
                cout << datos[i] << " ";
            }
            cout << endl;
        }
    }
};

int main() {
    PilaArreglo pila;
    int opcion, valor;

    do {
        cout << "
--- MENU PILA (ARREGLO ESTÁTICO) ---" << endl;
        cout << "1. Apilar (Push)" << endl;
        cout << "2. Desapilar (Pop)" << endl;
        cout << "3. Mostrar" << endl;
        cout << "4. Salir" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                cout << "Ingrese valor: ";
                cin >> valor;
                pila.apilar(valor);
                break;
            case 2:
                pila.desapilar();
                break;
            case 3:
                pila.mostrar();
                break;
            case 4:
                cout << "Saliendo..." << endl;
                break;
            default:
                cout << "Opcion invalida." << endl;
        }
    } while (opcion != 4);

    return 0;
}
