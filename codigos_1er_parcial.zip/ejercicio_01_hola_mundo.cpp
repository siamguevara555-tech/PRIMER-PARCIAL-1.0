#include <iostream>
using namespace std;

class Saludo {
public:
    void mostrarMensaje() {
        cout << "Hola mundo" << endl;
    }
};

int main() {
    Saludo s;
    s.mostrarMensaje();
    return 0;
}
