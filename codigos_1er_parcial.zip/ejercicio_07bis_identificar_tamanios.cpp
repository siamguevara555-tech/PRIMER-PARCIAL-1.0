#include <iostream>
using namespace std;

class DummyClass {};

int main() {
    cout << "Tamaño int: " << sizeof(int) << " bytes\n";
    cout << "Tamaño objeto clase vacía: " << sizeof(DummyClass) << " byte\n";
    return 0;
}
