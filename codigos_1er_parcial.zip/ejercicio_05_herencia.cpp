#include <iostream>
using namespace std;

class CalculadoraBase {
public:
    double sumar(double a, double b) { return a + b; }
};

class CalculadoraAvanzada : public CalculadoraBase {
public:
    double multiplicar(double a, double b) { return a * b; }
};

int main() {
    CalculadoraAvanzada calc;
    cout << "Suma (Herencia): " << calc.sumar(4, 5) << "\nMultiplicación: " << calc.multiplicar(4, 5) << endl;
    return 0;
}
