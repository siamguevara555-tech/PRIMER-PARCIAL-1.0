#include <iostream>
using namespace std;

class RecursividadCalc {
public:
    int factorial(int n) {
        if(n <= 1) return 1;
        return n * factorial(n - 1);
    }
};

int main() {
    RecursividadCalc rc;
    cout << "Factorial: " << rc.factorial(5) << endl;
    return 0;
}
