#include <iostream>
using namespace std;

class FractalSim {
public:
    void generarCantor(int n, int longitud) {
        if(n <= 0 || longitud < 1) return;
        cout << "Nivel: " << n << endl;
        generarCantor(n - 1, longitud / 3);
    }
};

int main() {
    FractalSim fs;
    fs.generarCantor(3, 9);
    return 0;
}
