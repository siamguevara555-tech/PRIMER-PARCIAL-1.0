#include <iostream>
#include <string>
using namespace std;

class RegistroPuntero {
private:
    string personas[2] = {"Luis", "Maria"};
public:
    void accederIndirecto() {
        string* ptr = personas;
        for(int i=0; i<2; i++) cout << *(ptr + i) << endl;
    }
};

int main() {
    RegistroPuntero rp;
    rp.accederIndirecto();
    return 0;
}
