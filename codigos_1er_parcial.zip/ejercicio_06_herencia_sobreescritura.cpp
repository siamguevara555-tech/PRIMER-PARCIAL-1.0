#include <iostream>
using namespace std;

class BaseCalc {
public:
    virtual double operar(double a, double b) { return a + b; }
};

class SubCalc : public BaseCalc {
public:
    double multiplicar(double a, double b) {
        double res = 0;
        for(int i = 0; i < (int)b; i++) res += a;
        return res;
    }
    double potencia(double base, int exp) {
        double res = 1;
        for(int i = 0; i < exp; i++) res *= base;
        return res;
    }
};

int main() {
    SubCalc sc;
    cout << "Mult por sumas: " << sc.multiplicar(3, 4) << "\nPotencia: " << sc.potencia(2, 3) << endl;
    return 0;
}
