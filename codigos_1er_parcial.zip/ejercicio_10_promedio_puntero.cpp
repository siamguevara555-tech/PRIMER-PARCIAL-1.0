#include <iostream>
using namespace std;

class PunteroArreglo {
private:
    double arr[5];
public:
    void llenar() { for(int i=0; i<5; i++) cin >> *(arr + i); }
    double promedioIndirecto() {
        double suma = 0;
        for(int i=0; i<5; i++) suma += *(arr + i);
        return suma / 5.0;
    }
};

int main() {
    PunteroArreglo pa;
    pa.llenar();
    cout << "Promedio indirecto: " << pa.promedioIndirecto() << endl;
    return 0;
}
