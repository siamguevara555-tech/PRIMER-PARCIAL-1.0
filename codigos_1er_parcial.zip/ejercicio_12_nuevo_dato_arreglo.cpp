#include <iostream>
#include <string>
using namespace std;

class Registro {
public:
    string nombres[2];
    string modelos[2];
    void mostrar() {
        for(int i=0; i<2; i++)
            cout << "Persona: " << nombres[i] << ", Coche: " << modelos[i] << endl;
    }
};

int main() {
    Registro r;
    r.nombres[0] = "Carlos"; r.modelos[0] = "Toyota";
    r.mostrar();
    return 0;
}
