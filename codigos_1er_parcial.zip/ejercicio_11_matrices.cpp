#include <iostream>
using namespace std;

class MatrizOp {
public:
    void multiplicarConstante(int mat[2][2], int c) {
        for(int i=0; i<2; i++)
            for(int j=0; j<2; j++) cout << mat[i][j] * c << " ";
    }
};

int main() {
    MatrizOp mo;
    int A[2][2]={{1,2},{3,4}};
    mo.multiplicarConstante(A, 3);
    return 0;
}
