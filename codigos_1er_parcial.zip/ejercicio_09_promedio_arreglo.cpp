#include <iostream>
using namespace std;

class ArregloEstadistica {
private:
    double numeros[5];
public:
    void leer() { for(int i=0; i<5; i++) cin >> numeros[i]; }
    double calcularPromedio() {
        double suma = 0;
        for(int i=0; i<5; i++) suma += numeros[i];
        return suma / 5.0;
    }
};

int main() {
    ArregloEstadistica ae;
    ae.leer();
    cout << "Promedio: " << ae.calcularPromedio() << endl;
    return 0;
}
