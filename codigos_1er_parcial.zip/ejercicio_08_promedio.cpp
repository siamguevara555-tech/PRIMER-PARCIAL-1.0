#include <iostream>
using namespace std;

class Estadistica {
public:
    void calcularPromedio() {
        double suma = 0, n;
        for(int i=0; i<5; i++) {
            cin >> n;
            suma += n;
        }
        cout << "Promedio: " << suma / 5.0 << endl;
    }
};

int main() {
    Estadistica est;
    est.calcularPromedio();
    return 0;
}
