#include <iostream>
#include <string>
using namespace std;

class Auto {
public:
    string modelo;
    double precio;
    int anio;
};

class Persona {
public:
    string nombre, ap, am, genero;
    int edad;
};

int main() {
    Auto miAuto{"Sedan", 150000.0, 2022};
    Persona p{"Ana", "Perez", "Gomez", "Femenino", 20};
    cout << "Auto: " << miAuto.modelo << ", Persona: " << p.nombre << endl;
    return 0;
}
