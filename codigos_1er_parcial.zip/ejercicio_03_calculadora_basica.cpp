#include <iostream>
using namespace std;

class CalculadoraBasica {
public:
    double sumar(double a, double b) { return a + b; }
    double restar(double a, double b) { return a - b; }
    double multiplicar(double a, double b) { return a * b; }
    double dividir(double a, double b) { return (b != 0) ? (a / b) : 0; }
};

int main() {
    CalculadoraBasica calc;
    cout << "Suma: " << calc.sumar(10, 5) << "\nResta: " << calc.restar(10, 5) << endl;
    return 0;
}
