#include <iostream>
using namespace std;

class Operacion {
public:
    double sumar(double a, double b) {
        return a + b;
    }
};

int main() {
    Operacion op;
    cout << "Suma: " << op.sumar(5.5, 4.5) << endl;
    return 0;
}
