#include <iostream>
using namespace std;

class CalculadoraSobrecargada {
public:
    double calcular() { return 0.0; }
    double calcular(double a, double b) { return a + b; }
    double calcular(double a, double b, double c) { return a + b + c; }
};

int main() {
    CalculadoraSobrecargada calc;
    cout << "0 params: " << calc.calcular() << "\n3 params: " << calc.calcular(1, 2, 3) << endl;
    return 0;
}
