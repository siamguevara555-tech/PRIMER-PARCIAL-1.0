#include <iostream>
#include <list>
using namespace std;

int main() {
    list<int> miLista;
    int opcion, valor;

    do {
        cout << "
--- MENU LISTA (STL std::list) ---" << endl;
        cout << "1. Insertar al final (push_back)" << endl;
        cout << "2. Eliminar por valor (remove)" << endl;
        cout << "3. Mostrar lista" << endl;
        cout << "4. Salir" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                cout << "Ingrese valor: ";
                cin >> valor;
                miLista.push_back(valor);
                cout << "Elemento " << valor << " insertado." << endl;
                break;
            case 2:
                if (miLista.empty()) {
                    cout << "Lista vacia." << endl;
                } else {
                    cout << "Ingrese valor a eliminar: ";
                    cin >> valor;
                    miLista.remove(valor);
                    cout << "Proceso de eliminacion finalizado." << endl;
                }
                break;
            case 3:
                if (miLista.empty()) {
                    cout << "Lista vacia." << endl;
                } else {
                    cout << "Contenido de la lista STL: ";
                    for (int elem : miLista) {
                        cout << elem << " <-> ";
                    }
                    cout << "END" << endl;
                }
                break;
            case 4:
                cout << "Saliendo..." << endl;
                break;
            default:
                cout << "Opcion invalida." << endl;
        }
    } while (opcion != 4);

    return 0;
}
