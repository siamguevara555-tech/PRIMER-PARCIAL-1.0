#include <iostream>
#include <stack>
using namespace std;

int main() {
    stack<int> pila;
    int opcion, valor;

    do {
        cout << "
--- MENU PILA (STL std::stack) ---" << endl;
        cout << "1. Apilar (push)" << endl;
        cout << "2. Desapilar (pop)" << endl;
        cout << "3. Ver Tope (top)" << endl;
        cout << "4. Salir" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                cout << "Ingrese valor: ";
                cin >> valor;
                pila.push(valor);
                cout << "Elemento " << valor << " apilado." << endl;
                break;
            case 2:
                if (pila.empty()) {
                    cout << "Pila vacia." << endl;
                } else {
                    cout << "Elemento " << pila.top() << " desapilado." << endl;
                    pila.pop();
                }
                break;
            case 3:
                if (pila.empty()) {
                    cout << "Pila vacia." << endl;
                } else {
                    cout << "El tope de la pila es: " << pila.top() << endl;
                }
                break;
            case 4:
                cout << "Saliendo..." << endl;
                break;
            default:
                cout << "Opcion invalida." << endl;
        }
    } while (opcion != 4);

    return 0;
}
